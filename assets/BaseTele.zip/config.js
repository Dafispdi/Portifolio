module.exports = {
  BOT_TOKEN: "BOT_TOKEN",
};

//=========================//
//Credits Base: @OBITOBOYS
//==========================//